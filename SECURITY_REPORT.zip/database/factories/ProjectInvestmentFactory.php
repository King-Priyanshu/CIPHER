<?php

namespace Database\Factories;

use App\Models\Project;
use App\Models\ProjectInvestment;
use App\Models\User;
use App\Models\UserSubscription;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\ProjectInvestment>
 */
class ProjectInvestmentFactory extends Factory
{
    protected $model = ProjectInvestment::class;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'user_id' => User::factory(),
            'project_id' => Project::factory(),
            'subscription_id' => UserSubscription::factory(),
            'amount' => $this->faker->numberBetween(100, 5000),
            'allocation_type' => 'auto',
            'status' => 'active',
            'allocated_at' => now(),
        ];
    }
}
