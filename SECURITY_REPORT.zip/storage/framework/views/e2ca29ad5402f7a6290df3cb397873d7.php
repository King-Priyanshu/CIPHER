<?php if (isset($component)) { $__componentOriginale310028fac676219cec01c7a3fccae2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale310028fac676219cec01c7a3fccae2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.subscriber','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.subscriber'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Subscription
     <?php $__env->endSlot(); ?>

    <div class="max-w-4xl">
        <!-- Current Plan -->
        <div class="card p-8 mb-8">
            <h3 class="text-lg font-bold text-navy mb-6">Current Subscription</h3>
            
            <?php if($subscription && $subscription->isActive()): ?>
                <div class="flex items-center justify-between p-4 bg-teal-50 border border-teal-100 rounded-xl mb-6">
                    <div class="flex items-center gap-4">
                        <div class="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center text-teal-600">
                            <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                        </div>
                        <div>
                            <p class="text-lg font-bold text-navy"><?php echo e($subscription->plan->name); ?> Plan</p>
                            <p class="text-slate-600 text-sm">Valid until <?php echo e($subscription->ends_at ? $subscription->ends_at->format('F j, Y') : 'forever'); ?></p>
                        </div>
                    </div>
                    <span class="px-3 py-1 bg-teal-600 text-white text-xs font-bold uppercase tracking-wider rounded-full">Active</span>
                </div>

                <!-- Refund / Cancellation Zone -->
                <div class="mt-6 pt-6 border-t border-gray-100">
                    <h4 class="text-sm font-bold text-red-600 mb-2">Danger Zone</h4>
                    <p class="text-xs text-slate-500 mb-4">You can cancel your subscription and request a full refund anytime before the 11-month maturity date.</p>
                    
                    <form action="<?php echo e(route('subscriber.refund.store')); ?>" method="POST" onsubmit="return confirm('Are you sure you want to cancel your subscription and request a refund? This action cannot be undone.');">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="reason" class="block text-xs font-medium text-slate-700 mb-1">Reason for cancellation</label>
                            <textarea name="reason" id="reason" rows="2" class="w-full text-sm border-gray-300 rounded-lg focus:ring-red-500 focus:border-red-500" placeholder="Please let us know why..." required></textarea>
                            <div class="flex items-center gap-2 mt-2">
                                <input type="checkbox" name="confirm" id="confirm" required class="rounded border-gray-300 text-red-600 focus:ring-red-500">
                                <label for="confirm" class="text-xs text-slate-600">I understand that my investments will be withdrawn.</label>
                            </div>
                        </div>
                        <button type="submit" class="text-sm text-red-600 font-bold hover:text-red-700 hover:underline">
                            Cancel Subscription & Request Refund
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <div class="bg-slate-50 p-6 rounded-xl border border-gray-100 text-center mb-6">
                    <p class="text-slate-500">You are currently on the <span class="font-bold text-navy">Free Tier</span>.</p>
                </div>
            <?php endif; ?>

            <h4 class="font-bold text-navy mb-4">Available Plans</h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded-xl p-6 <?php echo e(($subscription && $subscription->plan_id == $plan->id) ? 'border-teal-500 ring-1 ring-teal-500 bg-teal-50/10' : 'border-gray-200 hover:border-teal-300'); ?> transition">
                        <div class="flex justify-between items-start mb-4">
                            <h5 class="font-bold text-navy text-lg"><?php echo e($plan->name); ?></h5>
                            <span class="text-xl font-bold text-teal-600">₹<?php echo e(number_format($plan->price, 2)); ?><span class="text-sm text-slate-400 font-normal">/mo</span></span>
                        </div>
                        <ul class="space-y-2 mb-6 text-sm text-slate-600">
                            <?php if(is_array($plan->features)): ?>
                                <?php $__currentLoopData = $plan->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex items-center gap-2">
                                        <svg class="w-4 h-4 text-teal-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                        </svg>
                                        <?php echo e($feature); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>

                        <?php if($subscription && $subscription->plan_id == $plan->id): ?>
                            <button disabled class="w-full py-2 bg-slate-100 text-slate-400 font-semibold rounded-lg cursor-not-allowed">Current Plan</button>
                        <?php elseif($subscription): ?>
                            <form action="<?php echo e(route('subscriber.subscription.change-plan')); ?>" method="POST" onsubmit="return confirm('Change to <?php echo e($plan->name); ?>?');">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="plan_id" value="<?php echo e($plan->id); ?>">
                                <button type="submit" class="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg transition">
                                    <?php echo e($plan->price > $subscription->plan->price ? 'Upgrade' : 'Downgrade'); ?> to <?php echo e($plan->name); ?>

                                </button>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('checkout.show', $plan->slug)); ?>" class="block w-full py-2 bg-navy hover:bg-slate-800 text-white text-center font-semibold rounded-lg transition">
                                Subscribe Now
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale310028fac676219cec01c7a3fccae2f)): ?>
<?php $attributes = $__attributesOriginale310028fac676219cec01c7a3fccae2f; ?>
<?php unset($__attributesOriginale310028fac676219cec01c7a3fccae2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale310028fac676219cec01c7a3fccae2f)): ?>
<?php $component = $__componentOriginale310028fac676219cec01c7a3fccae2f; ?>
<?php unset($__componentOriginale310028fac676219cec01c7a3fccae2f); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/subscriber/subscription/index.blade.php ENDPATH**/ ?>