<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Investments <?php $__env->endSlot(); ?>

    <!-- Stats -->
    <!-- Stats -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="card p-6">
            <p class="text-sm font-medium text-slate-500">Pooled Funds</p>
            <p class="text-3xl font-bold text-amber-600 mt-1">₹<?php echo e(number_format($stats['pooled_funds'], 0)); ?></p>
        </div>
        <div class="card p-6">
            <p class="text-sm font-medium text-slate-500">Total Invested</p>
            <p class="text-3xl font-bold text-navy mt-1">₹<?php echo e(number_format($stats['total_invested'], 0)); ?></p>
        </div>
        <div class="card p-6">
            <p class="text-sm font-medium text-slate-500">Total Investors</p>
            <p class="text-3xl font-bold text-navy mt-1"><?php echo e($stats['total_investors']); ?></p>
        </div>
        <div class="card p-6">
            <p class="text-sm font-medium text-slate-500">Active Investments</p>
            <p class="text-3xl font-bold text-navy mt-1"><?php echo e($stats['active_investments']); ?></p>
        </div>
    </div>

    <!-- Manual Allocation -->
    <div class="card mb-6">
        <div class="p-4 border-b border-gray-100 flex justify-between items-center">
            <h3 class="text-lg font-bold text-navy">Manual Allocation</h3>
            <span class="text-xs text-slate-400">Allocate user funds to a specific project</span>
        </div>
        <div class="p-4">
            <form action="<?php echo e(route('admin.investments.allocate')); ?>" method="POST" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <?php echo csrf_field(); ?>
                <div class="flex-1">
                    <label class="block text-sm font-medium text-slate-600 mb-1">User</label>
                    <select name="user_id" class="w-full rounded-lg border-gray-300 text-sm" required>
                        <option value="">Select User</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->name); ?> (Available: ₹<?php echo e(number_format($user->subscription?->amount - $user->subscription?->allocated_amount, 0)); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="flex-1">
                    <label class="block text-sm font-medium text-slate-600 mb-1">Project</label>
                    <select name="project_id" class="w-full rounded-lg border-gray-300 text-sm" required>
                        <option value="">Select Project</option>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($project->id); ?>" <?php echo e(old('project_id') == $project->id ? 'selected' : ''); ?>>
                                <?php echo e($project->title); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="flex-1">
                    <label class="block text-sm font-medium text-slate-600 mb-1">Amount (₹)</label>
                    <input type="number" name="amount" min="1" step="0.01" class="w-full rounded-lg border-gray-300 text-sm" placeholder="e.g. 5000" required value="<?php echo e(old('amount')); ?>">
                </div>
                <div>
                    <button type="submit" class="w-full px-4 py-2 bg-teal-600 text-white rounded-lg text-sm font-medium hover:bg-teal-700 transition">
                        Allocate Funds
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-6">
        <div class="p-4 border-b border-gray-100">
            <form method="GET" class="flex flex-wrap gap-4 items-end">
                <div class="flex-1 min-w-[200px]">
                    <label class="block text-sm font-medium text-slate-600 mb-1">Project</label>
                    <select name="project_id" class="w-full rounded-lg border-gray-300 text-sm">
                        <option value="">All Projects</option>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($project->id); ?>" <?php echo e(request('project_id') == $project->id ? 'selected' : ''); ?>>
                                <?php echo e($project->title); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="flex-1 min-w-[200px]">
                    <label class="block text-sm font-medium text-slate-600 mb-1">Status</label>
                    <select name="status" class="w-full rounded-lg border-gray-300 text-sm">
                        <option value="">All Status</option>
                        <option value="allocated" <?php echo e(request('status') == 'allocated' ? 'selected' : ''); ?>>Allocated</option>
                        <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="withdrawn" <?php echo e(request('status') == 'withdrawn' ? 'selected' : ''); ?>>Withdrawn</option>
                    </select>
                </div>
                <button type="submit" class="px-4 py-2 bg-navy text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition">
                    Filter
                </button>
            </form>
        </div>
    </div>

    <!-- Investments Table -->
    <div class="card overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 class="text-lg font-bold text-navy">All Investments</h3>
            <div class="flex gap-2">
                <form action="<?php echo e(route('admin.investments.auto-allocate')); ?>" method="POST" onsubmit="return confirm('Run Auto-Allocation for ALL eligible auto-mode users?');">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn-secondary text-xs px-3 py-1.5">
                        Run Auto Allocation
                    </button>
                </form>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-slate-50 border-b border-gray-100">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">User</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Project</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Amount</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Status</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Allocated</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50/50 transition">
                        <td class="px-6 py-4">
                            <div class="flex items-center">
                                <div class="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-sm">
                                    <?php echo e(substr($investment->user->name, 0, 1)); ?>

                                </div>
                                <div class="ml-3">
                                    <p class="text-sm font-semibold text-navy"><?php echo e($investment->user->name); ?></p>
                                    <p class="text-xs text-slate-400"><?php echo e($investment->user->email); ?></p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm text-navy"><?php echo e($investment->project->title); ?></td>
                        <td class="px-6 py-4 text-sm font-bold text-navy">₹<?php echo e(number_format($investment->amount, 2)); ?></td>
                        <td class="px-6 py-4">
                            <span class="inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium
                                <?php echo e($investment->status === 'active' ? 'bg-green-100 text-green-800' : ''); ?>

                                <?php echo e($investment->status === 'allocated' ? 'bg-blue-100 text-blue-800' : ''); ?>

                                <?php echo e($investment->status === 'withdrawn' ? 'bg-gray-100 text-gray-800' : ''); ?>">
                                <?php echo e(ucfirst($investment->status)); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-500">
                            <?php echo e($investment->allocated_at?->format('M d, Y') ?? '-'); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center text-slate-400">
                            No investments found.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($investments->hasPages()): ?>
        <div class="px-6 py-4 border-t border-gray-100">
            <?php echo e($investments->links()); ?>

        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/admin/investments/index.blade.php ENDPATH**/ ?>