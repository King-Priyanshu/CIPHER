<?php if (isset($component)) { $__componentOriginale310028fac676219cec01c7a3fccae2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale310028fac676219cec01c7a3fccae2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.subscriber','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.subscriber'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Add Funds
     <?php $__env->endSlot(); ?>

    <div class="max-w-4xl">
        <div class="card p-8 mb-8">
            <h3 class="text-lg font-bold text-navy mb-2">Purchase Investment Plan</h3>
            <p class="text-slate-500 mb-6">Select a plan to add funds to your wallet. You can purchase multiple times.</p>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded-xl p-6 border-gray-200 hover:border-teal-300 transition">
                        <div class="flex justify-between items-start mb-4">
                            <h5 class="font-bold text-navy text-lg"><?php echo e($plan->name); ?></h5>
                            <span class="text-xl font-bold text-teal-600">₹<?php echo e(number_format($plan->price, 0)); ?></span>
                        </div>
                        <ul class="space-y-2 mb-6 text-sm text-slate-600">
                            <?php if(is_array($plan->features)): ?>
                                <?php $__currentLoopData = $plan->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex items-center gap-2">
                                        <svg class="w-4 h-4 text-teal-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                        </svg>
                                        <?php echo e($feature); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>

                        <a href="<?php echo e(route('checkout.show', $plan->slug)); ?>" class="block w-full py-2 bg-navy hover:bg-slate-800 text-white text-center font-semibold rounded-lg transition">
                            Buy Now
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale310028fac676219cec01c7a3fccae2f)): ?>
<?php $attributes = $__attributesOriginale310028fac676219cec01c7a3fccae2f; ?>
<?php unset($__attributesOriginale310028fac676219cec01c7a3fccae2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale310028fac676219cec01c7a3fccae2f)): ?>
<?php $component = $__componentOriginale310028fac676219cec01c7a3fccae2f; ?>
<?php unset($__componentOriginale310028fac676219cec01c7a3fccae2f); ?>
<?php endif; ?>
<?php /**PATH /www/wwwroot/cipher/resources/views/subscriber/subscription/index.blade.php ENDPATH**/ ?>