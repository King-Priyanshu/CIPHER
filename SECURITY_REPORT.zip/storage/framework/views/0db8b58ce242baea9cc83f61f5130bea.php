

<?php $__env->startSection('page_title', 'Reward Pools'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
            <h3 class="text-xl font-bold text-navy">Reward Pools</h3>
            <a href="<?php echo e(route('admin.reward-pools.create')); ?>" class="btn-primary">
                + New Reward Pool
            </a>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-4 p-4 rounded-lg bg-light-teal text-teal border border-teal/20">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="overflow-x-auto">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Project</th>
                        <th>Total Amount</th>
                        <th>Distributed</th>
                        <th>Status</th>
                        <th>Distribution Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="font-medium text-navy"><?php echo e($pool->project->title ?? 'N/A'); ?></td>
                        <td class="font-numbers text-teal font-semibold">₹<?php echo e(number_format($pool->total_amount, 2)); ?></td>
                        <td class="font-numbers text-slate">₹<?php echo e(number_format($pool->distributed_amount, 2)); ?></td>
                        <td>
                            <?php if($pool->status == 'distributed'): ?>
                                <span class="badge-success">Distributed</span>
                            <?php elseif($pool->status == 'pending'): ?>
                                <span class="badge-warning">Pending</span>
                            <?php else: ?>
                                <span class="badge">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-slate text-sm">
                            <?php echo e($pool->distribution_date ? $pool->distribution_date->format('M d, Y') : 'Not set'); ?>

                        </td>
                        <td>
                            <?php if($pool->status != 'distributed'): ?>
                                <form action="<?php echo e(route('admin.reward-pools.distribute', $pool)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="text-success hover:text-green-700 font-medium mr-3 transition-colors" onclick="return confirm('Distribute rewards?')">Distribute</button>
                                </form>
                            <?php endif; ?>
                            <a href="<?php echo e(route('admin.reward-pools.edit', $pool)); ?>" class="text-teal hover:text-navy font-medium mr-3 transition-colors">Edit</a>
                            <form action="<?php echo e(route('admin.reward-pools.destroy', $pool)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-error hover:text-red-700 font-medium transition-colors" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-6 py-8 text-center text-slate">No reward pools found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-6">
            <?php echo e($pools->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/wwwroot/cipher/resources/views/admin/reward-pools/index.blade.php ENDPATH**/ ?>