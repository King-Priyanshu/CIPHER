<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Payments <?php $__env->endSlot(); ?>

    <!-- Stats -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="card p-6">
            <p class="text-sm font-medium text-slate-500">Total Revenue</p>
            <p class="text-3xl font-bold text-navy mt-1">₹<?php echo e(number_format($stats['total_revenue'], 0)); ?></p>
        </div>
        <div class="card p-6">
            <p class="text-sm font-medium text-slate-500">Total Payments</p>
            <p class="text-3xl font-bold text-navy mt-1"><?php echo e($stats['total_payments']); ?></p>
        </div>
        <div class="card p-6">
            <p class="text-sm font-medium text-slate-500">Successful</p>
            <p class="text-3xl font-bold text-green-600 mt-1"><?php echo e($stats['successful']); ?></p>
        </div>
        <div class="card p-6">
            <p class="text-sm font-medium text-slate-500">Failed</p>
            <p class="text-3xl font-bold text-red-600 mt-1"><?php echo e($stats['failed']); ?></p>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-6">
        <div class="p-4">
            <form method="GET" class="flex flex-wrap gap-4 items-end">
                <div class="flex-1 min-w-[150px]">
                    <label class="block text-sm font-medium text-slate-600 mb-1">Status</label>
                    <select name="status" class="w-full rounded-lg border-gray-300 text-sm">
                        <option value="">All Status</option>
                        <option value="succeeded" <?php echo e(request('status') == 'succeeded' ? 'selected' : ''); ?>>Succeeded</option>
                        <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="failed" <?php echo e(request('status') == 'failed' ? 'selected' : ''); ?>>Failed</option>
                    </select>
                </div>
                <div class="flex-1 min-w-[150px]">
                    <label class="block text-sm font-medium text-slate-600 mb-1">Gateway</label>
                    <select name="gateway" class="w-full rounded-lg border-gray-300 text-sm">
                        <option value="">All Gateways</option>
                        <option value="razorpay" <?php echo e(request('gateway') == 'razorpay' ? 'selected' : ''); ?>>Razorpay</option>
                    </select>
                </div>
                <button type="submit" class="px-4 py-2 bg-navy text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition">
                    Filter
                </button>
            </form>
        </div>
    </div>

    <!-- Payments Table -->
    <div class="card overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="text-lg font-bold text-navy">All Payments</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-slate-50 border-b border-gray-100">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">ID</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">User</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Gross</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Net (Est.)</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Gateway</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Status</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Date</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50/50 transition">
                        <td class="px-6 py-4 text-sm font-mono text-slate-600">#<?php echo e($payment->id); ?></td>
                        <td class="px-6 py-4">
                            <div class="flex items-center">
                                <div class="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-sm">
                                    <?php echo e(substr($payment->user->name ?? 'U', 0, 1)); ?>

                                </div>
                                <div class="ml-3">
                                    <p class="text-sm font-semibold text-navy"><?php echo e($payment->user->name ?? 'Unknown'); ?></p>
                                    <p class="text-xs text-slate-400"><?php echo e($payment->user->email ?? ''); ?></p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm font-bold text-navy">₹<?php echo e(number_format($payment->amount, 2)); ?></td>
                        <td class="px-6 py-4 text-sm font-mono text-slate-500">₹<?php echo e(number_format($payment->amount * 0.98, 2)); ?></td>
                        <td class="px-6 py-4 text-sm text-slate-600 capitalize"><?php echo e($payment->gateway ?? 'N/A'); ?></td>
                        <td class="px-6 py-4">
                            <span class="inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium
                                <?php echo e($payment->status === 'succeeded' ? 'bg-green-100 text-green-800' : ''); ?>

                                <?php echo e($payment->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : ''); ?>

                                <?php echo e($payment->status === 'failed' ? 'bg-red-100 text-red-800' : ''); ?>">
                                <?php echo e(ucfirst($payment->status)); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-500"><?php echo e($payment->created_at->format('M d, Y H:i')); ?></td>
                        <td class="px-6 py-4">
                            <a href="<?php echo e(route('admin.payments.show', $payment)); ?>" class="text-teal-600 hover:underline text-sm font-medium">View</a>
                            <?php if(!$payment->invoice): ?>
                                <form action="<?php echo e(route('admin.invoices.generate', $payment)); ?>" method="POST" class="inline ml-2">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="text-blue-600 hover:underline text-sm font-medium">
                                        Generate Invoice
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="px-6 py-12 text-center text-slate-400">
                            No payments found.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($payments->hasPages()): ?>
        <div class="px-6 py-4 border-t border-gray-100">
            <?php echo e($payments->links()); ?>

        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/admin/payments/index.blade.php ENDPATH**/ ?>