<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Audit Logs
     <?php $__env->endSlot(); ?>

    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-navy">Audit Logs</h1>
        <span class="text-sm text-slate-500">Read-Only Secure Ledger</span>
    </div>

    <!-- Filters -->
    <div class="card p-4 mb-6">
        <form action="<?php echo e(route('admin.audit-logs.index')); ?>" method="GET" class="flex flex-wrap gap-4 items-end">
            <div>
                <label class="block text-xs font-bold text-navy mb-1">User ID</label>
                <input type="text" name="user_id" value="<?php echo e(request('user_id')); ?>" class="input w-32" placeholder="ID...">
            </div>
            <div>
                <label class="block text-xs font-bold text-navy mb-1">Action</label>
                <input type="text" name="action" value="<?php echo e(request('action')); ?>" class="input w-48" placeholder="e.g. profit.distributed">
            </div>
            <div>
                <button type="submit" class="btn btn-navy">Filter</button>
                <a href="<?php echo e(route('admin.audit-logs.index')); ?>" class="btn btn-ghost ml-2">Reset</a>
            </div>
        </form>
    </div>

    <!-- Table -->
    <div class="card overflow-hidden">
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-slate-50 border-b border-gray-100 text-xs text-slate-500 uppercase">
                    <th class="p-4">Timestamp</th>
                    <th class="p-4">User</th>
                    <th class="p-4">Action</th>
                    <th class="p-4">Description</th>
                    <th class="p-4">IP / Agent</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 text-sm md:text-base">
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50/50">
                        <td class="p-4 whitespace-nowrap text-slate-500 text-xs">
                            <?php echo e($log->created_at->format('M d, Y H:i:s')); ?>

                        </td>
                        <td class="p-4">
                            <?php if($log->user): ?>
                                <a href="<?php echo e(route('admin.users.show', $log->user_id)); ?>" class="font-bold text-navy hover:text-teal-600">
                                    <?php echo e($log->user->name); ?>

                                </a>
                                <div class="text-xs text-slate-400">ID: <?php echo e($log->user_id); ?></div>
                            <?php else: ?>
                                <span class="text-slate-400">System / Unknown</span>
                            <?php endif; ?>
                        </td>
                        <td class="p-4">
                            <span class="px-2 py-1 rounded text-xs font-bold bg-slate-100 text-slate-600 font-mono">
                                <?php echo e($log->action); ?>

                            </span>
                        </td>
                        <td class="p-4 text-slate-600 max-w-md break-words">
                            <?php echo e($log->description); ?>

                            <?php if($log->entity_type): ?>
                                <div class="text-xs text-slate-400 mt-1">
                                    Entity: <?php echo e(class_basename($log->entity_type)); ?> #<?php echo e($log->entity_id); ?>

                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="p-4 text-xs text-slate-400">
                            <div><?php echo e($log->ip_address ?? '-'); ?></div>
                            <div class="truncate max-w-[100px]" title="<?php echo e($log->user_agent); ?>"><?php echo e($log->user_agent ?? '-'); ?></div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="p-8 text-center text-slate-400">
                            No logs found matching your criteria.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        <?php echo e($logs->links()); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH /www/wwwroot/cipher/resources/views/admin/audit/index.blade.php ENDPATH**/ ?>