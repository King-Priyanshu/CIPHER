<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-200 leading-tight">
            <?php echo e(__('User Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-100">
                    <div class="mb-6 flex justify-between">
                        <h3 class="text-lg font-medium text-gray-200">Profile Information</h3>
                        <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="text-indigo-400 hover:text-indigo-300">Edit User</a>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <p class="text-sm font-medium text-gray-400">Name</p>
                            <p class="mt-1 text-lg text-gray-100"><?php echo e($user->name); ?></p>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-400">Email</p>
                            <p class="mt-1 text-lg text-gray-100"><?php echo e($user->email); ?></p>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-400">Roles</p>
                            <div class="mt-1">
                                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200">
                                        <?php echo e(ucfirst($role->name)); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-400">Joined</p>
                            <p class="mt-1 text-lg text-gray-100"><?php echo e($user->created_at->format('M d, Y h:i A')); ?></p>
                        </div>
                    </div>

                    <hr class="my-8 border-gray-700">

                    <h3 class="text-lg font-medium text-gray-200 mb-4">Subscription Status</h3>
                    
                    <?php if($user->subscription): ?>
                        <div class="bg-gray-750 p-4 rounded-md border border-gray-700">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <p class="text-sm font-medium text-gray-400">Plan</p>
                                    <p class="mt-1 text-gray-100"><?php echo e($user->subscription->plan->name ?? 'Unknown Plan'); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-400">Status</p>
                                    <p class="mt-1">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                            <?php echo e($user->subscription->isActive() ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'); ?>">
                                            <?php echo e(ucfirst($user->subscription->status)); ?>

                                        </span>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-400">Ends At</p>
                                    <p class="mt-1 text-gray-100"><?php echo e($user->subscription->ends_at ? $user->subscription->ends_at->format('M d, Y') : 'Auto-renewing'); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <p class="text-gray-400">User has no active subscription.</p>
                    <?php endif; ?>

                    <hr class="my-8 border-gray-700">

                    <h3 class="text-lg font-medium text-gray-200 mb-4">Participated Projects</h3>
                     <!-- Placeholder for projects list, maybe a small table or list -->
                    <p class="text-gray-400 italic">Project participation details coming soon.</p>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/admin/users/show.blade.php ENDPATH**/ ?>