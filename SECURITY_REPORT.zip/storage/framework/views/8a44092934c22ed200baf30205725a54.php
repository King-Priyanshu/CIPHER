

<?php $__env->startSection('page_title', 'Subscription Plans'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
            <h3 class="text-xl font-bold text-navy">All Plans</h3>
            <a href="<?php echo e(route('admin.plans.create')); ?>" class="btn-primary">
                + New Plan
            </a>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-4 p-4 rounded-lg bg-light-teal text-teal border border-teal/20">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="overflow-x-auto">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Interval</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="font-medium text-navy"><?php echo e($plan->name); ?></td>
                        <td class="font-numbers text-slate">₹<?php echo e(number_format($plan->price, 2)); ?> <span class="text-xs uppercase">INR</span></td>
                        <td><?php echo e(ucfirst($plan->interval)); ?></td>
                        <td>
                            <span class="<?php echo e($plan->is_active ? 'badge-success' : 'badge-error'); ?>">
                                <?php echo e($plan->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.plans.edit', $plan)); ?>" class="text-teal hover:text-navy font-medium mr-3 transition-colors">Edit</a>
                            <form action="<?php echo e(route('admin.plans.destroy', $plan)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-error hover:text-red-700 font-medium transition-colors" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-slate">No plans found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-6">
            <?php echo e($plans->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/wwwroot/cipher/resources/views/admin/plans/index.blade.php ENDPATH**/ ?>