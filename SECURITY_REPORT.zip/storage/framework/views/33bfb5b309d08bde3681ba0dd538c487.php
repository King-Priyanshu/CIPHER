

<?php $__env->startSection('page_title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <h3 class="text-xl font-bold text-navy">All Projects</h3>
        <a href="<?php echo e(route('admin.projects.create')); ?>" class="btn-primary">
            + New Project
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="mb-4 p-4 rounded-lg bg-light-teal text-teal border border-teal/20">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="overflow-x-auto">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Status</th>
                    <th>Fund Goal</th>
                    <th>Current Fund</th>
                    <th>Dates</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <!-- TITLE -->
                    <td class="font-medium text-navy">
                        <?php echo e($project->title); ?>

                    </td>

                    <!-- ✅ STATUS (FIXED: NOW INSIDE <td>) -->
                    <td>
                        <?php if($project->status === 'active'): ?>
                            <span class="badge badge-success">Active</span>
                        <?php elseif($project->status === 'paused'): ?>
                            <span class="badge badge-warning">Paused</span>
                        <?php elseif($project->status === 'completed'): ?>
                            <span class="badge badge-purple">Completed</span>
                        <?php elseif($project->status === 'cancelled'): ?>
                            <span class="badge badge-error">Cancelled</span>
                        <?php else: ?>
                            <span class="badge">Draft</span>
                        <?php endif; ?>
                    </td>

                    <!-- FUND GOAL -->
                    <td class="font-numbers text-slate">
                        ₹<?php echo e(number_format($project->fund_goal, 2)); ?>

                    </td>

                    <!-- CURRENT FUND -->
                    <td class="font-numbers text-teal font-semibold">
                        ₹<?php echo e(number_format($project->current_fund, 2)); ?>

                    </td>

                    <!-- DATES -->
                    <td class="text-slate text-sm">
                        <?php echo e($project->starts_at?->format('M d, Y') ?? 'Not set'); ?>

                        <?php if($project->ends_at): ?>
                            <br>
                            <span class="text-xs text-slate/70">
                                to <?php echo e($project->ends_at->format('M d, Y')); ?>

                            </span>
                        <?php endif; ?>
                    </td>

                    <!-- ACTIONS -->
                    <td class="whitespace-nowrap">
                        <a href="<?php echo e(route('admin.projects.edit', $project)); ?>"
                           class="action-btn action-edit mr-2">
                            Edit
                        </a>

                        <form action="<?php echo e(route('admin.projects.destroy', $project)); ?>"
                              method="POST"
                              class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                    onclick="return confirm('Are you sure?')"
                                    class="action-btn action-delete">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-6 py-10 text-center text-slate">
                        No projects found.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        <?php echo e($projects->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/wwwroot/cipher/resources/views/admin/projects/index.blade.php ENDPATH**/ ?>