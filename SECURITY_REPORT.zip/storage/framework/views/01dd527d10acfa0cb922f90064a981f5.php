

<?php $__env->startSection('page_title', 'Create Content Page'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto">
        <div class="card">
            <h3 class="text-xl font-bold text-navy mb-6">Create New Page</h3>
            
            <form action="<?php echo e(route('admin.pages.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="title" class="block text-sm font-medium text-navy mb-1.5">Title</label>
                        <input type="text" name="title" id="title" value="<?php echo e(old('title')); ?>" required
                            class="input-field" placeholder="Page Title">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-error"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="meta_title" class="block text-sm font-medium text-navy mb-1.5">Meta Title (SEO)</label>
                        <input type="text" name="meta_title" id="meta_title" value="<?php echo e(old('meta_title')); ?>"
                            class="input-field" placeholder="SEO Title">
                        <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-error"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="md:col-span-2">
                        <label for="meta_description" class="block text-sm font-medium text-navy mb-1.5">Meta Description (SEO)</label>
                        <input type="text" name="meta_description" id="meta_description" value="<?php echo e(old('meta_description')); ?>"
                            class="input-field" placeholder="Brief description for search engines">
                        <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-error"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="flex items-center md:col-span-2">
                        <input type="checkbox" name="is_published" id="is_published" value="1" <?php echo e(old('is_published', true) ? 'checked' : ''); ?>

                            class="w-4 h-4 rounded border-gray-300 text-teal focus:ring-teal">
                        <label for="is_published" class="ml-2 block text-sm text-navy">Published</label>
                    </div>
                </div>

                <div class="mt-6">
                    <label for="content" class="block text-sm font-medium text-navy mb-1.5">Content (HTML)</label>
                    <textarea name="content" id="content" rows="12" required
                        class="input-field font-mono text-sm"><?php echo e(old('content')); ?></textarea>
                    <p class="mt-1 text-xs text-slate">Basic HTML is supported.</p>
                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mt-8 flex justify-end space-x-3 border-t border-gray-100 pt-6">
                    <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn-ghost">Cancel</a>
                    <button type="submit" class="btn-primary">Create Page</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /www/wwwroot/cipher/resources/views/admin/pages/create.blade.php ENDPATH**/ ?>