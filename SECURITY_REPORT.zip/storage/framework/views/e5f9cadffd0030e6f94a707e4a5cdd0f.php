

<?php $__env->startSection('page_title', 'User Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">

    <!-- HEADER + SEARCH -->
    <div class="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <div>
            <h3 class="text-xl font-bold text-navy">All Users</h3>
            <p class="text-sm text-slate-500 mt-1">
                Manage all registered users and their roles.
            </p>
        </div>

        <form method="GET" action="<?php echo e(route('admin.users.index')); ?>"
              class="flex w-full sm:w-auto items-center gap-3 flex-wrap">

            <div class="relative w-full sm:w-64">
                <input
                    type="text"
                    name="search"
                    value="<?php echo e(request('search')); ?>"
                    placeholder="Search users..."
                    class="input-field h-11 pl-11 pr-4"
                >
                <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <svg class="w-5 h-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                </div>
            </div>

            <select name="status" class="rounded-lg border-gray-300 text-sm h-11">
                <option value="">All Status</option>
                <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                <option value="banned" <?php echo e(request('status') == 'banned' ? 'selected' : ''); ?>>Banned</option>
            </select>

            <select name="role" class="rounded-lg border-gray-300 text-sm h-11">
                <option value="">All Roles</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo e(request('role') == $role->id ? 'selected' : ''); ?>><?php echo e($role->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit" class="btn-primary h-11 px-6 text-sm">
                Filter
            </button>
        </form>
    </div>

    <!-- TABLE -->
    <div class="overflow-x-auto rounded-xl border border-gray-200">
        <table class="data-table">

            <thead>
            <tr>
                <th class="pl-6">User</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Joined</th>
                <th class="text-right pr-6">Actions</th>
            </tr>
            </thead>

            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>

                    <td class="pl-6">
                        <div class="flex items-center gap-4">
                            <div class="w-10 h-10 rounded-xl bg-teal-500 text-white font-bold flex items-center justify-center shadow-sm">
                                <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                            </div>
                            <div>
                                <div class="font-semibold text-sm text-navy">
                                    <?php echo e($user->name); ?>

                                </div>
                                <div class="text-xs text-slate-500 lg:hidden">
                                    <?php echo e($user->email); ?>

                                </div>
                            </div>
                        </div>
                    </td>

                    <td class="hidden lg:table-cell">
                        <?php echo e($user->email); ?>

                    </td>

                    <td>
                        <div class="flex gap-2 flex-wrap">
                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge <?php echo e($role->slug === 'admin' ? 'bg-purple-100 text-purple-700' : 'badge-success'); ?>">
                                    <?php echo e(ucfirst($role->name)); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </td>

                    <td>
                        <span class="inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium
                            <?php echo e($user->status === 'active' ? 'bg-green-100 text-green-800' : ''); ?>

                            <?php echo e($user->status === 'inactive' ? 'bg-yellow-100 text-yellow-800' : ''); ?>

                            <?php echo e($user->status === 'banned' ? 'bg-red-100 text-red-800' : ''); ?>">
                            <?php echo e(ucfirst($user->status ?? 'active')); ?>

                        </span>
                    </td>

                    <td class="whitespace-nowrap text-sm text-slate-600">
                        <?php echo e($user->created_at->format('M d, Y')); ?>

                    </td>

                    <td class="text-right pr-6">
                        <div class="flex justify-end gap-2 flex-wrap">
                            <a href="<?php echo e(route('admin.users.show', $user)); ?>"
                               class="action-btn action-view">View</a>

                            <a href="<?php echo e(route('admin.users.edit', $user)); ?>"
                               class="action-btn action-edit">Edit</a>

                            <?php if($user->id !== auth()->id()): ?>
                                <?php if($user->status !== 'active'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.users.activate', $user)); ?>" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <button class="action-btn bg-green-50 text-green-700 hover:bg-green-100">Activate</button>
                                    </form>
                                <?php endif; ?>

                                <?php if($user->status === 'active'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.users.deactivate', $user)); ?>" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <button class="action-btn bg-yellow-50 text-yellow-700 hover:bg-yellow-100">Deactivate</button>
                                    </form>
                                <?php endif; ?>

                                <?php if($user->status !== 'banned'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.users.ban', $user)); ?>"
                                          onsubmit="return confirm('Are you sure you want to ban this user?')" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <button class="action-btn action-delete">Ban</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center py-16 text-slate-400">
                        <div class="flex flex-col items-center justify-center gap-2">
                            <span class="text-3xl opacity-50">👥</span>
                             <span>No users found</span>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>

        </table>
    </div>

    <div class="mt-6">
        <?php echo e($users->withQueryString()->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('components.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/users/index.blade.php ENDPATH**/ ?>