<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Invoices <?php $__env->endSlot(); ?>

    <!-- Stats -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="card p-6">
            <p class="text-sm font-medium text-slate-500">Total Invoiced</p>
            <p class="text-3xl font-bold text-navy mt-1">₹<?php echo e(number_format($stats['total_invoiced'], 0)); ?></p>
        </div>
        <div class="card p-6">
            <p class="text-sm font-medium text-slate-500">Paid Invoices</p>
            <p class="text-3xl font-bold text-green-600 mt-1"><?php echo e($stats['paid_invoices']); ?></p>
        </div>
        <div class="card p-6">
            <p class="text-sm font-medium text-slate-500">Pending</p>
            <p class="text-3xl font-bold text-yellow-600 mt-1"><?php echo e($stats['pending_invoices']); ?></p>
        </div>
    </div>

    <!-- Invoices Table -->
    <div class="card overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="text-lg font-bold text-navy">All Invoices</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-slate-50 border-b border-gray-100">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Invoice #</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">User</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Amount</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Status</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Issued</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50/50 transition">
                        <td class="px-6 py-4 text-sm font-mono font-semibold text-navy"><?php echo e($invoice->invoice_number); ?></td>
                        <td class="px-6 py-4">
                            <div class="flex items-center">
                                <div class="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-sm">
                                    <?php echo e(substr($invoice->user->name ?? 'U', 0, 1)); ?>

                                </div>
                                <div class="ml-3">
                                    <p class="text-sm font-semibold text-navy"><?php echo e($invoice->user->name ?? 'Unknown'); ?></p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm font-bold text-navy">₹<?php echo e(number_format($invoice->total, 2)); ?></td>
                        <td class="px-6 py-4">
                            <span class="inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium
                                <?php echo e(($invoice->status ?? 'paid') === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                <?php echo e(ucfirst($invoice->status ?? 'paid')); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-500"><?php echo e($invoice->issued_at?->format('M d, Y')); ?></td>
                        <td class="px-6 py-4 flex gap-2">
                            <a href="<?php echo e(route('admin.invoices.show', $invoice)); ?>" class="text-teal-600 hover:underline text-sm font-medium">View</a>
                            <a href="<?php echo e(route('admin.invoices.download', $invoice)); ?>" class="text-blue-600 hover:underline text-sm font-medium" target="_blank">Download</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-6 py-12 text-center text-slate-400">
                            No invoices yet.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($invoices->hasPages()): ?>
        <div class="px-6 py-4 border-t border-gray-100">
            <?php echo e($invoices->links()); ?>

        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH /www/wwwroot/cipher/resources/views/admin/invoices/index.blade.php ENDPATH**/ ?>